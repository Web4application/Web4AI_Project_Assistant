// Copyright 2023 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

//go:build vendor

package main

import (
	// for vet
	_ "code.gitea.io/gitea-vet"
)

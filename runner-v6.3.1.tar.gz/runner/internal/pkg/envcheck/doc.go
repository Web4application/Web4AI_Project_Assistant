// Copyright 2023 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

// Package envcheck provides a simple way to check if the environment is ready to run jobs.
package envcheck
